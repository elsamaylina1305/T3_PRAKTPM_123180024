package com.example.recyclerviewmovieselsa;

import java.util.ArrayList;

public class MoviesData {
    private static String[] moviesNames = {
            "Balada Si Roy",
            "Yang Tak Tergantikan",
            "Cinta Pertama, Kedua, dan Ketiga",
            "Sri Asih",
            "Geez & Ann",
            "Ashiap Man",
            "Hujan di Balik Jendela",
            "Keluarga Slamet",
            "Surga yang Tak Dirindukan 3",
            "Tentang Rindu",
    };

    private static String[] moviesDetails = {
            "Balada Si Roy adalah film drama Indonesia tahun 2021 yang disutradarai Fajar Nugros dan menjadi produksi film panjang pertama IDN Pictures. Film ini merupakan adaptasi novel legendaris berjudul sama karya Gol A Gong.[1] Film tersebut dibintangi oleh Abidzar Al Ghifari sebagai Roy dan Febby Rastanty sebagai Ani.",
            "Yang Tak Tergantikan (bahasa Inggris: The Unchangeables) adalah sebuah film drama keluarga Indonesia tahun 2021 yang disutradarai oleh Herwin Novianto. Film ini dibintangi oleh Lulu Tobing, Dewa Dayana, Yasamin Jasem, dan Maisha Kanna.",
            "Cinta Pertama, Kedua & Ketiga adalah sebuah film drama Indonesia produksi Starvision Plus dan Wahana Kreator Nusantara yang disutradarai oleh Gina S. Noer. Film ini dibintangi oleh Angga Aldi Yunanda, Putri Marino, Slamet Rahardjo dan Ira Wibowo.",
            "Sri Asih adalah sebuah film laga hidup pahlawan super Indonesia yang disutradarai oleh Upi Avianto. Film ini diadaptasi dari seri buku komik klasik Indonesia, Sri Asih karya R. A. Kosasih.",
            "Geez & Ann adalah film drama romantis Indonesia tahun 2021 yang disutradarai oleh Rizki Balki produksi MVP Pictures. Film ini diadaptasi dari novel berjudul sama karya Nadhifa Allya Tsana.",
            "Ashiap Man merupakan film Indonesia yang akan dirilis pada tahun 2021. Film ini disutradarai oleh Atta Halilintar bersama Herdanius Larobu dan diproduksi oleh StarVision. Film ini merupakan debut penyutradaraan Atta Halilintar di film layar lebar.",
            "Hujan di Balik Jendela adalah film drama Indonesia tahun 2021 yang disutradarai oleh Dyan Sunu Prastowo. Film ini merupakan film perdana KlikFilm Productions bersama dengan film Tentang Rindu. Film ini dibintangi oleh Clara Bernadeth, Bio One, dan Yasamin Jasem",
            "Keluarga Slamet: Saat Buah Hati Malah Jadi Buah Bibir adalah film drama komedi Indonesia tahun 2021 yang disutradarai oleh Rako Prijanto dan diproduksi dibawah naungan Falcon Pictures. Ini adalah remake dari film India 2018 Badhaai Ho.", "Yowis Ben 3 adalah film Indonesia tahun 2021 yang disutradarai Fajar Nugros bersama Bayu Skak dan dibintangi oleh Bayu Skak, Joshua Suherman, Brandon Salim dan Tutus Thomson.",
            "Surga yang Tak Dirindukan 3 adalah film drama romantis Indonesia tahun 2021 yang disutradarai oleh Pritagita Arianegara produksi MD Pictures. Film ini diadaptasi dari novel Surga yang Tak Dirindukan karya Asma Nadia.",
            "Tentang Rindu adalah film drama Indonesia tahun 2021 yang disutradarai oleh Dyan Sunu Prastowo. Film Tentang Rindu merupakan film perdana KlikFilm Productions bersamaan dengan film Hujan di Balik Jendela. Film ini dibintangi oleh Omar Daniel dan Aurora Ribero."
    };

    private static int[] moviesImages = {
            R.drawable.balada,
            R.drawable.yang,
            R.drawable.cinta,
            R.drawable.sri,
            R.drawable.geez,
            R.drawable.ashiap,
            R.drawable.hujan,
            R.drawable.keluarga,
            R.drawable.surga,
            R.drawable.tentang
    };

    static ArrayList<MoviesModel> getListData(){
        ArrayList<MoviesModel> list = new ArrayList<>();
        for (int position = 0; position < moviesNames.length; position++){
            MoviesModel moviesmodel = new MoviesModel();
            moviesmodel.setName(moviesNames[position]);
            moviesmodel.setDetail(moviesDetails[position]);
            moviesmodel.setPhoto(moviesImages[position]);
            list.add(moviesmodel);
        }
        return list;
    }
}
